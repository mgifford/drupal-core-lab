# Reproduce and review: Drupal core issue #3604037

#3604037: groups (details, vertical tabs) that contain a field error say so, pinned core

Forms group fields in closed <details> and vertical tabs. When a field inside a closed or inactive group has an error, nothing on the group says so. The change (MR !17078, Default Admin theme) marks such groups with a red border, an icon, red label text, a hidden " (contains error)" label for screen readers and a data-child-error-count attribute. Follow the steps on three pages, then press Run checks on each page: the checks apply to the page the frames are on. Both sites carry the same test-page change (a second required field), so the page looks the same on both sides; only the code under test differs.

Bundle built 2026-10-02. Issue: https://www.drupal.org/project/drupal/issues/3604037

**Local development only.** Everything runs on your machine. The sites use `admin` / `admin`.
Nothing here is sent anywhere except downloads (Drupal core from git.drupalcode.org, Composer
packages, the DDEV add-on).

## What this lets you do
Run two copies of Drupal side by side: **Before** (pristine upstream `main`) and **After**
(the same code plus the patches in `reports/issues/3604037/`), and see the difference in one browser
window, with the steps, the expected result, and pass/fail checks on the page.

## You need
- [Docker](https://www.docker.com/) and [DDEV](https://ddev.com/) (1.24 or newer), git, Node.js 20+.
- About 10 GB of disk and 8 GB of memory free. First setup takes 10 to 20 minutes.
- Network access: Drupal core (git.drupalcode.org), Composer, npm (axe-core, installed by setup), the DDEV add-on.

## Quick start
```bash
cd drupal-repro-3604037
node tools/compare/setup.mjs 3604037-pinned      # builds both sites (clones Drupal core, installs, applies the recipe and patches)
node tools/compare/serve.mjs 3604037-pinned      # then open http://localhost:8100/
```
In the page: press **Log in both as admin**, choose **Phone** frame width, and follow the steps.
**Mirror clicks and typing** repeats your actions in both frames; turn it off for the final step,
which must be done in each frame by hand (and by keyboard). Then press **Run checks**.
Switch **View** to **Difference** to see anything that looks different (black means identical).
The **Accessibility, live (axe-core)** panel compares both sides after every page load and interaction and
alerts when After has more (or fewer) violations than Before.

## Coming back later, or trying updated Drupal core
`3604037-pinned` uses the pinned core commit `c321043bb82d`, so it reproduces exactly as verified.
To see whether it still works on current core:

```bash
node tools/compare/setup.mjs 3604037-pinned --check-patches    # do the patches still apply to the pinned core?
node tools/compare/setup.mjs 3604037-latest --check-patches    # ...and to the current core main?
node tools/compare/setup.mjs 3604037-latest                     # build Before and After on current main
node tools/playwright/walkthrough.mjs 3604037-latest            # needs: cd tools/playwright && npm install && npx playwright install chromium
```

`reports/issues/3604037/REPRODUCE.md` explains what each outcome means (a patch that no longer applies, a problem that no longer
reproduces because upstream fixed it, a fix that no longer works) and how to re-pin.

## What is in this bundle
| Path | What |
|---|---|
| `recipes/repro_3604037/` | Drupal recipe that creates the starting state (Article type, Path module, Inline Form Errors). |
| `reports/issues/3604037/` | The patches (`*.patch`, `branches/`), validation steps, status of related issues, and diff evidence. |
| `tools/compare/variants.json` | This comparison: environments, patches, steps, expected result, checks. |
| `tools/compare/` | The viewer (`serve.mjs`, `index.html`), the diff report (`diff.mjs`), and `setup.mjs`. |
| `scripts/lab-site.sh` | `apply` or `reset` a site to the recipe's state. |

## Steps to reproduce
1. Default Admin is the admin theme.
2. An Article content type, the Path module and the form_test test module are installed (setup enables test extensions).
3. Type /form_test/details-contains-required-fields in Page and press Go (both). A form appears with a collapsible section that contains required fields.
   *Look for:* A details section titled something like "Meta" with two required text fields inside.
4. Press the form's submit button without filling in anything.
   *Look for:* Error messages for the required fields.
5. Close the details section by clicking its title.
   *Look for:* Before: a plain closed section, nothing says it contains errors. After: it is marked as containing errors (red border, error icon, red title). Then press Run checks.
6. Open /node/add/article. Open the sidebar, open "URL alias", type a value with no leading slash (no-slash), close the sidebar, press Save.
   *Look for:* Open the sidebar again: After marks the "URL alias" group as containing an error even though it is closed. Run checks.
7. Open /admin/config/people/accounts (each frame must be at least 650 px wide: use Desktop or Tablet). In the Emails section clear the required Subject, press Save, then click a different vertical tab.
   *Look for:* The tab that contains the error is marked in After but not in Before. Run checks.
8. Dark mode: set Colour mode to Dark and repeat step 5 (and step 7). Compare the label, red bar and icon with the dark background.
   *Look for:* Everything is readable. Measured on current core: the dark error colour #ce6060 is 3.72:1 on the details summary and 4.48:1 on a tab label, both below the 4.5:1 needed for text; see reports/issues/3604037/EVALUATION-2026-10-01.md.
9. Hover and keyboard focus: hover the marked section's title, then press Tab until it has focus.
   *Look for:* The red bar and icon stay visible. While hovered the label turns link-blue (the error colour is lost for the label only). The focus ring is clearly visible and does not hide the error cue. Turn on 'Mirror hover and focus' to see where the pointer or focus is in the other frame.
10. Forced colours: press Open forced-colours window in the viewer, then in the new window press Log in both as admin, choose Forced colours, light (and later dark) and repeat step 5 and step 7. (docs/FORCED-COLORS.md has other ways.)
   *Look for:* After's marked group is still distinguishable without colour (the icon), and the icon is visible. The MR paints the icon CanvasText (black or white) while the label is link-coloured; see the proposal in the evaluation.
11. Narrow width: set Device width to Mobile and repeat step 7 (below about 650 px the tabs become accordion sections).
   *Look for:* The same red bar and icon appear on the section with the error, and the bar is not covered when the section is focused.
12. JavaScript off: tick 'Turn the sites' JavaScript off', then repeat step 4.
   *Look for:* The server-rendered error markers still appear on After (class error and a data-child-error-count attribute); there are none on Before.
13. Right to left: type /fa/form_test/details-contains-required-fields in Page (Farsi, a real right-to-left language added by setup), and repeat step 4 and step 5; then /fa/admin/config/people/accounts for step 7. (Without Farsi, set Text direction to Right to left instead.)
   *Look for:* The red bar moves to the right (start) edge, the icon sits at the end of the label, and nothing overlaps.

**Expected:** A closed details section or an inactive vertical tab that contains a field error is visibly marked (red border, icon, red text) and has hidden text " (contains error)" and a data-child-error-count attribute.
**Actual (before the change):** Before the change a closed or inactive group gives no sign that a field inside it has an error; the user must open each group to find it.

## Checks run by the page
| Type | Check | Expected |
|---|---|---|
| precondition | Setup reached: the test form shows required-field errors | true |
| precondition | A group (details) that contains the errors is on the page | true |
| fix | The details that contains errors has data-child-error-count | true |
| fix | The count is 2 (two required fields inside) | 2 |
| fix | The summary carries the hidden text "(contains error)" | (contains error) |
| precondition | Setup reached: the URL alias error is on the node form | true |
| fix | The closed URL alias group is marked (data-child-error-count) | true |
| fix | Its summary carries the hidden text "(contains error)" | (contains error) |
| precondition | Setup reached: the account settings form shows an error | true |
| fix | A vertical tab that contains an error is marked | true |
| fix | That tab has the hidden "(contains error)" text | true |
| regression | JavaScript errors on the page (ignoring the harmless "ResizeObserver loop" notice) | 0 |
| regression | Number of open details sections matches the other side | same on both sides |

"Fix" checks should differ between Before and After. "Regression" checks should pass on both.

## Useful commands
- Clear Drupal caches on both sites: the button in the page, or `ddev drupal cache` in each `envs/<name>/`.
- Rebuild a site from scratch: `scripts/lab-site.sh reset <env>` (destroys that site's content).
- Diff what the two sites serve: `node tools/compare/diff.mjs 3604037-pinned` (writes to `reports/issues/3604037/compare/`).
- Stop and remove: in each `envs/<name>/` run `ddev delete --omit-snapshot --yes`.
- If setup stops with `ddev-router failed to become ready` (DDEV's shared router sometimes misses its 60 second health check, more often with many DDEV projects running): just run the same `setup.mjs` command again, it resumes where it stopped. Running `ddev poweroff` first (stops all DDEV projects) makes it much less likely.
- If a site will not start after moving the folder: `ddev stop`, `ddev mutagen reset`, `ddev start`.

## What this does not replace
It compares behaviour in a browser and the files served. It does not replace testing with a
keyboard and a screen reader, which is the point of an accessibility change. The evidence here
is a DRAFT until a person has done that and reviewed it.

## Licence and provenance
The patches are changes to Drupal core (GPL-2.0-or-later). Drupal core is cloned from
git.drupalcode.org, not included. The viewer and scripts were written with AI assistance
(Claude Code) for the Drupal accessibility testing workflow. See `reports/issues/3604037/`
for sources and dates. Always check the issue on drupal.org: it is the source of truth.
