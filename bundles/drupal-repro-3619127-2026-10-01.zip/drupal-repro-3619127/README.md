# Reproduce and review: Drupal core issue #3619127

#3619127: sidebar opens from Inline Form Errors links (MR + vanilla JS), pinned core

Before: upstream main. After: MR !16895 with patch-0 (no jQuery) and patch-1 (no persist). Open /node/add/article in a narrow window, set a URL alias of 'no-slash' inside the sidebar, close the sidebar, Save, then use the error link. Before: nothing opens. After: the sidebar opens and the field gets focus.

Bundle built 2026-10-01. Issue: https://www.drupal.org/project/drupal/issues/3619127

**Local development only.** Everything runs on your machine. The sites use `admin` / `admin`.
Nothing here is sent anywhere except downloads (Drupal core from git.drupalcode.org, Composer
packages, the DDEV add-on).

## What this lets you do
Run two copies of Drupal side by side: **Before** (pristine upstream `main`) and **After**
(the same code plus the patches in `reports/issues/3619127/`), and see the difference in one browser
window, with the steps, the expected result, and pass/fail checks on the page.

## You need
- [Docker](https://www.docker.com/) and [DDEV](https://ddev.com/) (1.24 or newer), git, Node.js 20+.
- About 10 GB of disk and 8 GB of memory free. First setup takes 10 to 20 minutes.
- Network access: Drupal core (git.drupalcode.org), Composer, npm (axe-core, installed by setup), the DDEV add-on.

## Quick start
```bash
cd drupal-repro-3619127
node tools/compare/setup.mjs 3619127-pinned      # builds both sites (clones Drupal core, installs, applies the recipe and patches)
node tools/compare/serve.mjs 3619127-pinned      # then open http://localhost:8100/
```
In the page: press **Log in both as admin**, choose **Phone** frame width, and follow the steps.
**Mirror clicks and typing** repeats your actions in both frames; turn it off for the final step,
which must be done in each frame by hand (and by keyboard). Then press **Run checks**.
Switch **View** to **Difference** to see anything that looks different (black means identical).
The **Accessibility, live (axe-core)** panel compares both sides after every page load and interaction and
alerts when After has more (or fewer) violations than Before.

## Coming back later, or trying updated Drupal core
`3619127-pinned` uses the pinned core commit `d29add7ebc18`, so it reproduces exactly as verified.
To see whether it still works on current core:

```bash
node tools/compare/setup.mjs 3619127-pinned --check-patches    # do the patches still apply to the pinned core?
node tools/compare/setup.mjs 3619127-latest --check-patches    # ...and to the current core main?
node tools/compare/setup.mjs 3619127-latest                     # build Before and After on current main
node tools/playwright/walkthrough.mjs 3619127-latest            # needs: cd tools/playwright && npm install && npx playwright install chromium
```

`reports/issues/3619127/REPRODUCE.md` explains what each outcome means (a patch that no longer applies, a problem that no longer
reproduces because upstream fixed it, a fix that no longer works) and how to re-pin.

## What is in this bundle
| Path | What |
|---|---|
| `recipes/ife_sidebar_repro/` | Drupal recipe that creates the starting state (Article type, Path module, Inline Form Errors). |
| `reports/issues/3619127/` | The patches (`*.patch`, `branches/`), validation steps, status of related issues, and diff evidence. |
| `tools/compare/variants.json` | This comparison: environments, patches, steps, expected result, checks. |
| `tools/compare/` | The viewer (`serve.mjs`, `index.html`), the diff report (`diff.mjs`), and `setup.mjs`. |
| `scripts/lab-site.sh` | `apply` or `reset` a site to the recipe's state. |

## Steps to reproduce
1. Default Admin is the admin theme.
2. Article content type and the Path module (URL alias field) are installed.
3. The Inline Form Errors module is enabled.
4. Open /node/add/article (the page is already loaded in both frames once you press Go).
5. Use the Tablet or Phone frame width, so the sidebar of advanced fields is collapsed.
6. Click "Expand sidebar" to open it.
7. Open "URL alias" and type a value without a leading slash, for example no-slash.
8. Close the sidebar.
9. Click Save. An error appears at the top: "1 error has been found: URL alias", with "URL alias" as a link.
   *Look for:* An error summary at the top of the page, with "URL alias" as a link. If you do not see it, the setup went wrong; try again from step 6.
10. Turn Mirror off. In EACH frame, click the "URL alias" link with a REAL mouse click (then repeat using only the keyboard: Tab to the link, press Enter). Do not use a script: script-generated clicks do not trigger the focus behaviour being tested.
   *Look for:* Before: nothing visibly happens. After: the sidebar opens and the URL alias box is outlined (it has keyboard focus). Then press Run checks.

**Expected:** The sidebar opens and keyboard focus moves to the invalid URL alias field.
**Actual (before the change):** Before (upstream main): nothing happens. After (with the change): the sidebar opens and the field has focus.

## Checks run by the page
| Type | Check | Expected |
|---|---|---|
| precondition | Setup reached: error link to URL alias is on the page | true |
| precondition | The error link was used with a real click or key press, not a script | true |
| fix | Sidebar is open after using the error link | true |
| fix | URL alias field received keyboard focus (recorded when it happens: only one frame can hold focus at a time) | true |
| regression | Saved sidebar preference was not overwritten (phone/tablet key) | false |
| regression | JavaScript errors on the page (ignoring the harmless "ResizeObserver loop" notice) | 0 |
| regression | Number of open details sections matches the other side | same on both sides |

"Fix" checks should differ between Before and After. "Regression" checks should pass on both.

## Useful commands
- Clear Drupal caches on both sites: the button in the page, or `ddev drupal cache` in each `envs/<name>/`.
- Rebuild a site from scratch: `scripts/lab-site.sh reset <env>` (destroys that site's content).
- Diff what the two sites serve: `node tools/compare/diff.mjs 3619127-pinned` (writes to `reports/issues/3619127/compare/`).
- Stop and remove: in each `envs/<name>/` run `ddev delete --omit-snapshot --yes`.
- If setup stops with `ddev-router failed to become ready` (DDEV's shared router sometimes misses its 60 second health check, more often with many DDEV projects running): just run the same `setup.mjs` command again, it resumes where it stopped. Running `ddev poweroff` first (stops all DDEV projects) makes it much less likely.
- If a site will not start after moving the folder: `ddev stop`, `ddev mutagen reset`, `ddev start`.

## What this does not replace
It compares behaviour in a browser and the files served. It does not replace testing with a
keyboard and a screen reader, which is the point of an accessibility change. The evidence here
is a DRAFT until a person has done that and reviewed it.

## Licence and provenance
The patches are changes to Drupal core (GPL-2.0-or-later). Drupal core is cloned from
git.drupalcode.org, not included. The viewer and scripts were written with AI assistance
(Claude Code) for the Drupal accessibility testing workflow. See `reports/issues/3619127/`
for sources and dates. Always check the issue on drupal.org: it is the source of truth.
